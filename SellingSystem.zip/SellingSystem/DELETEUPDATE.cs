﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SellingSystem
{
    class DELETEUPDATE: Program
    {
        #region Delete Reservation

        public void Delete()
        {
            Program p = new Program();
            DELETEUPDATE d = new DELETEUPDATE();

           



        login:
            String firstname, password;

            Console.WriteLine("\n\n\n\n\t\t\t\t\t\t\t                 DELETE YOUR RESERVATION\n\n");
            Console.Write("\n\n\t\t\t\t\t\t\tPlease Input Firstname:");
            firstname = Console.ReadLine();
            Console.Write("\t\t\t\t\t\t\tPlease Input Password:");
            password = Console.ReadLine();

            try
            {
                User respond = DataSet.CustomerList.Find(r => (r.FirstName == firstname) && (r.Password == password));


                Console.WriteLine("\n\n\t\t\t\t\t\t\tPress D(delete)");
                Console.WriteLine("\t\t\t\t\t\t\tPress C(cancel)");
                Console.Write("\n\t\t\t\t\t\t\tCHOOSE OPTION:");
                string c = Console.ReadLine().ToString();


                switch (c)
                {
                    case "D":
                    case "d":
                        d.CLEAN(respond);

                        Console.WriteLine("\n\n\n\n\n\n\t\t\t\t\t\t\t\t\t\tYour data Has Been Deleted!!!     Thank You..");

                        Console.Write("\n\n\t\t\t\t\t\t\t\t\t\tPress any key to Continue......");

                        Console.ReadLine();
                        Console.Clear();
                        p.ProgramStart();
                        Console.Clear();
                        Console.ReadLine();

                        break;
                    case "C":
                    case "c":
                        Console.WriteLine("Thank You Have A Blessed Day!!!");
                        Console.Read();
                        break;

                    default:

                        Console.Write("invalid input");
                        break;
                };

                Console.Read();
            }
            catch
            {
                Console.Clear();
                Console.WriteLine("Invalid Credentials !!!");
                goto login;
            }

        }




        #endregion

        #region Clean Reservation

        public void CLEAN(User respond)
        {
            respond.FirstName = null;
            respond.Username= null;
            respond.LastName= null;
            respond.MiddleName = null;
            respond.Password = null;
            respond.Birthday = null;
            respond.Id = null;
            
         

        }


        #endregion



        public void UPDATE()
        {

            Program p = new Program();


            Console.WriteLine("\n\n\n\n\t\t\t\t\t\t\t                 UPDATE YOUR RESERVATION\n\n");


        login:
            String firstname, password;

            Console.WriteLine("\n\t\t\t\t\t\t\t                      L O G  I N");
            Console.Write("\n\n\t\t\t\t\t\t\tPlease Input User Name:");
            firstname = Console.ReadLine();
            Console.Write("\t\t\t\t\t\t\tPlease Input Password:");
            password = Console.ReadLine();

            try
            {
                User respond = DataSet.CustomerList.Find(r => (r.FirstName == firstname) && (r.Password == password));

                Console.WriteLine("\n\n\t\t\t\t\t\t\tWHAT DO YOU WANT TO CHANGE?");

                Console.WriteLine("\n\n\t\t\t\t\t\t\tA.USER new Firstname");
                Console.WriteLine("\n\n\t\t\t\t\t\t\tB.USER new LastName");
                Console.WriteLine("\n\n\t\t\t\t\t\t\tC.USER new MiddleName");
                Console.WriteLine("\n\n\t\t\t\t\t\t\tD.USER new Birthday");
                Console.WriteLine("\n\n\t\t\t\t\t\t\tE.USER new UserName");
                Console.WriteLine("\n\n\t\t\t\t\t\t\tF.USER new Password");
                Console.WriteLine("\n\n\t\t\t\t\t\t\tG.USER new ID");
              
                Console.Write("\n\n\t\t\t\t\t\t\tWhat Is Your Choice?:");
                string Change = Console.ReadLine().ToString();

                if (Change == "A" || Change == "a")
                {
                    Console.Write("\n\t\t\t\t\t\t\tInput new Firstname:");
                    respond.FirstName = Console.ReadLine().ToString();
                }
                else if (Change == "B" || Change == "b")
                {
                    Console.Write("\n\t\t\t\t\t\t\tInput new Lastname:");
                    respond.LastName= Console.ReadLine().ToString();
                }
                else if (Change == "C" || Change == "c")
                {
                    Console.Write("\n\t\t\t\t\t\t\tInput new Middlename");
                    respond.MiddleName = Console.ReadLine().ToString();
                }
                else if (Change == "D" || Change == "d")
                {
                    Console.Write("\n\t\t\t\t\t\t\tInput new User Name:");
                    respond.Birthday = Console.ReadLine().ToString();
                }
                else if (Change == "E" || Change == "e")
                {
                    Console.Write("\n\t\t\t\t\t\t\tInput new Password:");
                    respond.Username = Console.ReadLine().ToString();
                }
                else if (Change == "F" || Change == "f")
                {
                    Console.Write("\n\t\t\t\t\t\t\tInput new Address:");
                    respond.Password = Console.ReadLine().ToString();
                }
                if (Change == "G" || Change == "g")
                {
                    Console.Write("\n\t\t\t\t\t\t\tInput new Event:");
                    respond.Id = Console.ReadLine().ToString();

                }
                
                {

                    Console.Read();

                }

            }

            catch
            {
                Console.Clear();
                Console.WriteLine("Invalid Credentials !!!");
                goto login;
            }


            Console.Write("\n\t\t\t\t\t\t\tPress any key to Continue......");

            Console.ReadLine();
            Console.Clear();
            p.ProgramStart();
            Console.Clear();
            Console.ReadLine();


        }

    }
}
