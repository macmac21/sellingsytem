﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SellingSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Program p = new Program();
            p.InitData();
            p.ProgramStart();
            Console.Read();
        }
        public void ProgramStart()
        {
            var guid = Guid.NewGuid().ToString();
            Program p = new Program();

        home:

            switch (p.Home())
            {
                case "a":
                case "A":
                    p.Login();
                    break;
                case "b":
                case "B":
                    p.Register();
                    break;
                default:
                    Console.Clear();
                    Console.WriteLine("========================================================================");
                    Console.WriteLine("\t\t\t\tInvalid Choice");
                    Console.WriteLine("========================================================================");

                    goto home;

            };

        }
        public string Home()
        {
            string option;
            Console.WriteLine("\n************************************************************************");
            Console.WriteLine("\t\t\t\tWELCOME TO");
            Console.WriteLine("\t\tMARKENZ MARKETING SERVICES");
            Console.WriteLine("************************************************************************");
            Console.WriteLine("================================= OPTION ===============================");
            Console.WriteLine("*************************    A. Login          *************************");
            Console.WriteLine("*************************    B. Register       *************************");
            Console.WriteLine("========================================================================");
            Console.Write("\t\t\tSelect Option:   ");
            option = Console.ReadLine();
            Console.Clear();

            return option;
        }
        public void Login()
        {
        login:
            Program p = new Program();
            string username, password;
            Console.WriteLine("============================================================================");
            Console.WriteLine("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx LOGIN xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
            Console.WriteLine("\t************** Please Input the following **************");
            Console.WriteLine("============================================================================");
            Console.Write("\n\tUsername: ");
            username = Console.ReadLine();
            System.Console.Write("\n\tPassword: ");
            password = null;

            while (true)
            {
                var key = System.Console.ReadKey(true);
                if (key.Key == ConsoleKey.Enter)
                    break;
                password += key.KeyChar;
                System.Console.Write("*");

            }
            Console.Clear();

            try
            {
                User respond = DataSet.CustomerList.Find(r => (r.Username == username) && (r.Password == password));

                switch ((respond.Id))
                {
                    case "a":
                    case "A":
                        Login();
                        break;
                };
            }
            catch
            {

                Console.Clear();
                Console.WriteLine("============================================================================");
                Console.WriteLine("\t\t\t\tThe Account Does'nt exist!");
                Console.WriteLine("============================================================================");
                goto login;
            }
            p.LoginHome();

        }
        public void Register()
        {
            Program p = new Program();
            String firstname, lastname, middlename, username, password, birthday;
            Console.WriteLine("===============================================================================");
            Console.WriteLine("xxxxxxxxxxxxxxxxxxxxxxxxxxxxx Registration Form xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
            Console.WriteLine("\t************** Please input the following **************");
            Console.WriteLine("===============================================================================");
            Console.Write("\tFirst Name:  ");
            firstname = Console.ReadLine();
            Console.Write("\tLast Name:   ");
            lastname = Console.ReadLine();
            Console.Write("\tMiddle Name: ");
            middlename = Console.ReadLine();
            Console.Write("\tBirthday:    ");
            birthday = Console.ReadLine();
            Console.Write("\tUsername:    ");
            username = Console.ReadLine();
            Console.Write("\tPassword:    ");
            password = Console.ReadLine();
            Console.Clear();

            User u = new User(Guid.NewGuid().ToString(), firstname, lastname, middlename, birthday, username, password);
            DataSet.CustomerList.Add(u);
            p.LoginHome();
        }
        public void EmployeeInfo()
        {
            Program p = new Program();
            String firstname, lastname, middlename, address, status, gender, cellnum, bday, department;
            byte age;

            Console.WriteLine("==============================================================");
            Console.WriteLine("xxxxxxxxxxxxxxxxxxxxxxxx Employee Data xxxxxxxxxxxxxxxxxxxxxxx");
            Console.WriteLine("\t************** Please input the following **************");
            Console.WriteLine("==============================================================");
            Console.Write("\tFirst Name:         ");
            firstname = Console.ReadLine();
            Console.Write("\tLast Name:          ");
            lastname = Console.ReadLine();
            Console.Write("\tMiddle Name:        ");
            middlename = Console.ReadLine();
            Console.Write("\tAddress:            ");
            address = Console.ReadLine();
            Console.Write("\tBirthday:           ");
            bday = Console.ReadLine();
            Console.Write("\tAge:                ");
            age = byte.Parse(Console.ReadLine());
            Console.Write("\tCivil Status:       ");
            status = Console.ReadLine();
            Console.Write("\tGender:             ");
            gender = Console.ReadLine();
            Console.Write("\tCell Number:        ");
            cellnum = Console.ReadLine();
            Console.Write("\tDepartment:      ");
            department = Console.ReadLine();
            Console.Clear();
            Admin e = new Admin(Guid.NewGuid().ToString(), firstname, lastname, middlename);
            DataSet.AdminList.Add(e);
            p.LoginHome();

        }
        public String LoginHome()
        {
            string id;
            id = Console.ReadLine();
            Program p = new Program();
            DELETEUPDATE d = new DELETEUPDATE();
            User respond;
            String option = "";
            try
            {
                respond = DataSet.CustomerList.Find(r => (r.Id == id));

                Console.WriteLine("***********************************************************************************");
                Console.WriteLine("\t\t\t\tWELCOME TO");
                Console.WriteLine("\t\tMARKENZ MARKETING SERVICES");
                Console.WriteLine("***********************************************************************************");
                Console.WriteLine("===================================================================================");
                Console.WriteLine("====================================== OPTION =====================================");
                Console.WriteLine("********************    A. MOTOR STAR                          ********************");
                Console.WriteLine("********************    B. HONDA                               ********************");
                Console.WriteLine("********************    C. YAMAHA                              ********************");
                Console.WriteLine("********************    D. RUSI                                ********************");
                Console.WriteLine("********************    E. Add New Employee                    ********************");
                Console.WriteLine("********************    F. View Employee                       ********************");
                Console.WriteLine("********************    G. VIEW USER LIST                      ********************");
                Console.WriteLine("********************    H. UPDATE                              ********************");
                Console.WriteLine("********************    I. DELETE                              ********************");
                Console.WriteLine("********************    J. EXIT                                ********************");
                Console.WriteLine("===================================================================================");
                Console.WriteLine("===================================================================================");
                Console.Write("\t\t\tSelect an Option:   ");
                option = Console.ReadLine();
                Console.Clear();
                login:
                switch (option)
                {
                    case "a":
                    case "A":
                        p.MotorStar();
                        break;
                    case "b":
                    case "B":
                        p.Honda();
                        break;
                    case "c":
                    case "C":
                        p.Yamaha();
                        break;
                    case "d":
                    case "D":
                        p.Rusi();
                        break;
                    case "e":
                    case "E":
                        EmployeeInfo();
                        break;
                    case "f":
                    case "F":
                        EmployeeUpdate();
                        break;
                    case "g":
                    case "G":
                        DisplayUserList();
                        break;
                    case "h":
                    case "H":
                        d.UPDATE();
                        break;
                    case "i":
                    case "I":
                        d.Delete();
                        break;
                    default:
                        Console.WriteLine("\t\t\t\tInvalid Input");
                        break;
                        goto login;
                }
            }
            catch
            {
                Console.Clear();
            }

            return option;
        }
        public void MotorStar()
        {
            var guid = Guid.NewGuid().ToString();
            Program p = new Program();

            switch (p.MxrUnits())
            {
                case "1":
                    M110();
                    break;
                case "2":
                    M125();
                    break;
                case "3":
                    Mx100();
                    break;
                case "4":
                    Mx125();
                    break;
                case "5":
                    Mxr125();
                    break;
                case "6":
                    Mxr150();
                    break;
                case "7":
                    Mxr155();
                    break;
                default:
                    Console.Clear();
                    Console.WriteLine("========================================================================");
                    Console.WriteLine("\t\t\t\tInvalid Choice");
                    Console.WriteLine("========================================================================");
                    break;

            }

        }
        public String MxrUnits()
        {
            string input;
            Console.WriteLine("****************************************************************************************************");
            Console.WriteLine("***                                      MOTOR STAR UNITS                                        ***");
            Console.WriteLine("---------------------------------------------------------------------------------------------------*");
            Console.WriteLine("***    M                              |     MX                      |    MXR                       |");
            Console.WriteLine("***    >1. M110fi = P65,000.00        |     >3. MX100 = P65,000.00  |      >5. MXR125 = P60,000.00 |");
            Console.WriteLine("***    >2. M125fi = P75,000.00        |     >4. MX125 = P70,000.00  |      >6. MXR150 = P80,000.00 |");
            Console.WriteLine("***                                   |                             |      >7. MXR155 = P95,000.00 |");
            Console.WriteLine("***                                   |                             |                              |");
            Console.WriteLine("****************************************************************************************8***********");
            Console.Write("Select Unit: ");
            input = Console.ReadLine();

            return input;
        }
        public void M110()
        {
            double cash, change, price;
            Program p = new Program();
            Console.WriteLine("M110: ");
            Console.WriteLine("     Unit Price: P65,000.00");
            Console.Write("Enter Cash: ");
            cash = double.Parse(Console.ReadLine());
            price = 65000;
            change = cash - price;
            Console.Write("Change: "+ change,"");
            Console.Read();
        }
        public void M125()
        {
            double cash, price, change;
            Program p = new Program();
            Console.WriteLine("M125: ");
            Console.WriteLine("     Unit Price: P75,000.00");
            Console.Write("Enter Cash: ");
            cash = double.Parse(Console.ReadLine());
            price = 75000;
            change = cash - price;
            Console.Write("Change: " + change, "");
            Console.Read();
        }
        public void Mx100()
        {
            double cash, change, price;
            Program p = new Program();
            Console.WriteLine("MX100: ");
            Console.WriteLine("     Unit Price: P65,000.00");
            Console.Write("Enter Cash: ");
            cash = double.Parse(Console.ReadLine());
            price = 65000;
            change = cash - price;
            Console.Write("Change: " + change, "");
            Console.Read();
            Console.Clear();
        }
        public void Mx125()
        {
            double cash, change, price;
            Program p = new Program();
            Console.WriteLine("MX125: ");
            Console.WriteLine("     Unit Price: P70,000.00");
            Console.Write("Enter Cash: ");
            cash = double.Parse(Console.ReadLine());
            price = 70000;
            change = cash - price;
            Console.Write("Change: " + change, "");
            Console.Read();
            Console.Clear();
        }
        public void Mxr125()
        {
            double cash, change, price;
            Program p = new Program();
            Console.WriteLine("MXR125: ");
            Console.WriteLine("     Unit Price: P70,000.00");
            Console.Write("Enter Cash: ");
            cash = double.Parse(Console.ReadLine());
            price = 70000;
            change = cash - price;
            Console.Write("Change: " + change, "");
            Console.Read();
            Console.Clear();
        }
        public void Mxr150()
        {
            double cash, change, price;
            Program p = new Program();
            Console.WriteLine("TMX150: ");
            Console.WriteLine("     Unit Price: P80,000.00");
            Console.Write("Enter Cash: ");
            cash = double.Parse(Console.ReadLine());
            price = 80000;
            change = cash - price;
            Console.Write("Change: " + change, "");
            Console.Read();
            Console.Clear();
        }
        public void Mxr155()
        {
            double cash, change, price;
            Program p = new Program();
            Console.WriteLine("TMX155: ");
            Console.WriteLine("     Unit Price: P95,000.00");
            Console.Write("Enter Cash: ");
            cash = double.Parse(Console.ReadLine());
            price = 95000;
            change = cash - price;
            Console.Write("Change: " + change, "");
            Console.Read();
            Console.Clear();
        }
        public void Honda()
        {
            var guid = Guid.NewGuid().ToString();
            Program p = new Program();

            switch (p.Units())
            {
                case "1":
                    Xrm110();
                    break;
                case "2":
                    Xrm125();
                    break;
                case "3":
                    Rs100();
                    break;
                case "4":
                    Rs125();
                    break;
                case "5":
                    Tmx125();
                    break;
                case "6":
                    Tmx150();
                    break;
                case "7":
                    Tmx155();
                    break;
                default:
                    Console.Clear();
                    Console.WriteLine("========================================================================");
                    Console.WriteLine("\t\t\t\tInvalid Choice");
                    Console.WriteLine("========================================================================");
                    break;

            }

        }
        public String Units()
        {
            string input;
            Console.WriteLine("****************************************************************************************************");
            Console.WriteLine("***                                      HONDA UNITS                                             ***");
            Console.WriteLine("---------------------------------------------------------------------------------------------------*");
            Console.WriteLine("***    XRM                            |     RS                      |    TMX SUPREMO               |");
            Console.WriteLine("***    >1. XRM110fi = P65,000.00      |     >3. RS100 = P65,000.00  |      >5. TMX125 = P60,000.00 |");
            Console.WriteLine("***    >2. XRM125fi = P75,000.00      |     >4. RS125 = P70,000.00  |      >6. TMX150 = P80,000.00 |");
            Console.WriteLine("***                                   |                             |      >7. TMX155 = P95,000.00 |");
            Console.WriteLine("***                                   |                             |                              |");
            Console.WriteLine("****************************************************************************************8***********");
            Console.Write("Select Unit: ");
            input = Console.ReadLine();

            return input;
        }
        public void Xrm110()
        {
            Program p = new Program();
            Console.WriteLine("XRM110: ");
            Console.WriteLine("     Unit Price: P65,000.00");
            Console.Read();
            p.LoginHome();
            Console.Clear();
        }
        public void Xrm125()
        {
            Program p = new Program();
            Console.WriteLine("XRM125: ");
            Console.WriteLine("     Unit Price: P75,000.00");
            Console.Read();
            p.LoginHome();
            Console.Clear();
        }
        public void Rs100()
        {
            Program p = new Program();
            Console.WriteLine("RS100: ");
            Console.WriteLine("     Unit Price: P65,000.00");
            Console.Read();
            p.LoginHome();
            Console.Clear();
        }
        public void Rs125()
        {
            Program p = new Program();
            Console.WriteLine("RS125: ");
            Console.WriteLine("     Unit Price: P70,000.00");
            Console.Read();
            p.LoginHome();
            Console.Clear();
        }
        public void Tmx125()
        {
            Program p = new Program();
            Console.WriteLine("TMX125: ");
            Console.WriteLine("     Unit Price: P70,000.00");
            Console.Read();
            p.LoginHome();
            Console.Clear();
        }
        public void Tmx150()
        {
            Program p = new Program();
            Console.WriteLine("TMX150: ");
            Console.WriteLine("     Unit Price: P80,000.00");
            Console.Read();
            p.LoginHome();
            Console.Clear();
        }
        public void Tmx155()
        {
            Program p = new Program();
            Console.WriteLine("TMX155: ");
            Console.WriteLine("     Unit Price: P95,000.00");
            Console.Read();
            p.LoginHome();
            Console.Clear();
        }
        public void Yamaha()
        {
            var guid = Guid.NewGuid().ToString();
            Program p = new Program();

            switch (p.YUnits())
            {
                case "1":
                    Y110();
                    break;
                case "2":
                    Y125();
                    break;
                case "3":
                    YI100();
                    break;
                case "4":
                    YI125();
                    break;
                case "5":
                    YII125();
                    break;
                case "6":
                    YII150();
                    break;
                case "7":
                    YII155();
                    break;
                default:
                    Console.Clear();
                    Console.WriteLine("========================================================================");
                    Console.WriteLine("\t\t\t\tInvalid Choice");
                    Console.WriteLine("========================================================================");
                    break;

            }

        }
        public String YUnits()
        {
            string input;
            Console.WriteLine("****************************************************************************************************");
            Console.WriteLine("***                                      YAMAHA UNITS                                            ***");
            Console.WriteLine("---------------------------------------------------------------------------------------------------*");
            Console.WriteLine("***                                   |                             |                              |");
            Console.WriteLine("***    >1. Y110fi = P65,000.00        |     >3. YI100 = P65,000.00  |      >5. YII125 = P60,000.00 |");
            Console.WriteLine("***    >2. Y125fi = P75,000.00        |     >4. YI125 = P70,000.00  |      >6. YII150 = P80,000.00 |");
            Console.WriteLine("***                                   |                             |      >7. YII155 = P95,000.00 |");
            Console.WriteLine("***                                   |                             |                              |");
            Console.WriteLine("****************************************************************************************8***********");
            Console.Write("Select Unit: ");
            input = Console.ReadLine();

            return input;
        }
        public void Y110()
        {
            Program p = new Program();
            Console.WriteLine("Y110: ");
            Console.WriteLine("     Unit Price: P65,000.00");
            Console.Read();
            p.LoginHome();
            Console.Clear();
        }
        public void Y125()
        {
            Program p = new Program();
            Console.WriteLine("Y125: ");
            Console.WriteLine("     Unit Price: P75,000.00");
            Console.Read();
            p.LoginHome();
            Console.Clear();
        }
        public void YI100()
        {
            Program p = new Program();
            Console.WriteLine("YI100: ");
            Console.WriteLine("     Unit Price: P65,000.00");
            Console.Read();
            p.LoginHome();
            Console.Clear();
        }
        public void YI125()
        {
            Program p = new Program();
            Console.WriteLine("YI125: ");
            Console.WriteLine("     Unit Price: P70,000.00");
            Console.Read();
            p.LoginHome();
            Console.Clear();
        }
        public void YII125()
        {
            Program p = new Program();
            Console.WriteLine("YII125: ");
            Console.WriteLine("     Unit Price: P70,000.00");
            Console.Read();
            p.LoginHome();
            Console.Clear();
        }
        public void YII150()
        {
            Program p = new Program();
            Console.WriteLine("YII150: ");
            Console.WriteLine("     Unit Price: P80,000.00");
            Console.Read();
            p.LoginHome();
            Console.Clear();
        }
        public void YII155()
        {
            Program p = new Program();
            Console.WriteLine("TMX155: ");
            Console.WriteLine("     Unit Price: P95,000.00");
            Console.Read();
            p.LoginHome();
            Console.Clear();
        }
        public void Rusi()
        {
            var guid = Guid.NewGuid().ToString();
            Program p = new Program();

            switch (p.RUnits())
            {
                case "1":
                    R110();
                    break;
                case "2":
                    R125();
                    break;
                case "3":
                    RI100();
                    break;
                case "4":
                    RI125();
                    break;
                case "5":
                    RII125();
                    break;
                case "6":
                    RII150();
                    break;
                case "7":
                    RII155();
                    break;
                default:
                    Console.Clear();
                    Console.WriteLine("========================================================================");
                    Console.WriteLine("\t\t\t\tInvalid Choice");
                    Console.WriteLine("========================================================================");
                    break;

            }

        }
        public String RUnits()
        {
            string input;
            Console.WriteLine("****************************************************************************************************");
            Console.WriteLine("***                                      RUSI  UNITS                                             ***");
            Console.WriteLine("---------------------------------------------------------------------------------------------------*");
            Console.WriteLine("***                                   |                             |                              |");
            Console.WriteLine("***    >1. R110fi = P65,000.00        |     >3. RI100 = P65,000.00  |      >5. RII125 = P60,000.00 |");
            Console.WriteLine("***    >2. R125fi = P75,000.00        |     >4. RI125 = P70,000.00  |      >6. RII150 = P80,000.00 |");
            Console.WriteLine("***                                   |                             |      >7. RII155 = P95,000.00 |");
            Console.WriteLine("***                                   |                             |                              |");
            Console.WriteLine("****************************************************************************************8***********");
            Console.Write("Select Unit: ");
            input = Console.ReadLine();

            return input;
        }
        public void R110()
        {
            Program p = new Program();
            Console.WriteLine("R110: ");
            Console.WriteLine("     Unit Price: P65,000.00");
            Console.Read();
            p.LoginHome();
            Console.Clear();
        }
        public void R125()
        {
            Program p = new Program();
            Console.WriteLine("R125: ");
            Console.WriteLine("     Unit Price: P75,000.00");
            Console.Read();
            p.LoginHome();
            Console.Clear();
        }
        public void RI100()
        {
            Program p = new Program();
            Console.WriteLine("RI100: ");
            Console.WriteLine("     Unit Price: P65,000.00");
            Console.Read();
            p.LoginHome();
            Console.Clear();
        }
        public void RI125()
        {
            Program p = new Program();
            Console.WriteLine("RI125: ");
            Console.WriteLine("     Unit Price: P70,000.00");
            Console.Read();
            p.LoginHome();
            Console.Clear();
        }
        public void RII125()
        {
            Program p = new Program();
            Console.WriteLine("RII125: ");
            Console.WriteLine("     Unit Price: P70,000.00");
            Console.Read();
            p.LoginHome();
            Console.Clear();
        }
        public void RII150()
        {
            Program p = new Program();
            Console.WriteLine("RII150: ");
            Console.WriteLine("     Unit Price: P80,000.00");
            Console.Read();
            p.LoginHome();
            Console.Clear();
        }
        public void RII155()
        {
            Program p = new Program();
            Console.WriteLine("RII155: ");
            Console.WriteLine("     Unit Price: P95,000.00");
            Console.Read();
            p.LoginHome();
            Console.Clear();
        }
        public void AccountSetting()
        {
            Program p = new Program();
            p.DisplayUserList();
        }
        public void InitData()
        {
            string id1 = Guid.NewGuid().ToString();
            DataSet.CustomerList.Add(new User(Guid.NewGuid().ToString(), "Mark", "Grafe", "L", "April", "uwagan1", "1234"));
            DataSet.CustomerList.Add(new User(Guid.NewGuid().ToString(), "Renz", "Patual", "L", "April", "uwagan2", "1234"));

        }
        public void DisplayUserList()
        {
            Program p = new Program();
            {
                Console.WriteLine("==============================================================");
                Console.WriteLine("xxxxxxxxxxxxxxxxxxxxxxxx Users List xxxxxxxxxxxxxxxxxxxxxxx");
                Console.WriteLine("==============================================================");
                int count = 1;
                foreach (User s in DataSet.CustomerList)
                {
                    try
                    {

                        Console.WriteLine(count++ + " " + s.toString());
                    }
                    catch
                    {

                    }
                }
            }
        }
        public void EmployeeUpdate()
        {
            Program p = new Program();
            {
                Console.WriteLine("==============================================================");
                Console.WriteLine("xxxxxxxxxxxxxxxxxxxxxxxx Employee List xxxxxxxxxxxxxxxxxxxxxxx");
                Console.WriteLine("==============================================================");
                int count = 1;
                foreach (Admin s in DataSet.AdminList)
                {
                    try
                    {

                        Console.WriteLine(count++ + " " + s.toString());
                    }
                    catch
                    {

                    }
                }
            }
        }
        public void Exit()
        {
            Console.WriteLine("Thank you!");
            Console.WriteLine("Come Again!!");
        }
    }
}
